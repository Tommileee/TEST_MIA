class Target:
    MOTOR_LEFT = "motor-left"
    MOTOR_RIGHT = "motor-right"
    ARM_LEFT = "arm-left"
    ARM_RIGHT = "arm-right"
    HEAD_ROTATION = "head-rotation"
    HEAD_EXTENSION = "head-extension"
